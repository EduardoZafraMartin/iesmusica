<?php
    if(!isset ($_SESSION)){
        session_start();
    }

    if(!isset ($_SESSION ['logueado']) || ($_SESSION ['logueado'] ==false)){
        header("location: view_login.php");
    }
?>
<html>
   <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
     <title>SPOTIFY - IES Leonardo Da Vinci</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    </head>
   

   
   <body>
        <div class="container ">
        <!--Aplicacion-->
		<div class="card border-success mb-3" style="max-width: 30rem;">
		<div class="card-header">Descargar Canciones - SPOTIFY Leonardo Da Vinci</div>
		<div class="card-body">
	
	    

	<!-- INICIO DEL FORMULARIO -->
	<form action="../controllers/controller_descarga.php" method="post">
		
	<B>Nombre Cliente:</B><?php echo $_SESSION['FirstName']; ?> <BR>
	<B>Id Cliente:</B><?php echo $_SESSION['CustomerId']; ?> <BR>
	<B>Compañia:</B> <?php echo $_SESSION['Company']; ?><BR><BR>

            <?php foreach ($_SESSION['DESCARGA_CANCIONES'] as $cancionSeleccionada) : ?>
            <?php echo ("La cancion y el precio es: " . $cancionSeleccionada ); ?><br>
            <?php endforeach; ?><br><br>
	
		<label for="cancion"><B>Selecciona canción: </B></label>
       

        <select name="cancion" class="form-control" style="text-align:left;color: red;background: #f0f0f0;" required>
        <?php foreach ($canciones as $cancion) : ?>
                <?php $datos = $cancion['TrackId'] . "_and_" . $cancion['UnitPrice']; echo '<option value="' . $datos . '"> Cancion ' . $cancion['Name'] .' Artista ' . $cancion['Composer'] . 
                ' Precio ' . $cancion['UnitPrice'] . '</option>'; ?>
            <?php endforeach; ?>
       
           
        </select><br><br>	
		<div>
			<input type="submit" value="Agregar a Cesta" name="agregar" class="btn btn-warning disabled">
			<input type="submit" value="Descargar" name="descargar" class="btn btn-warning disabled">
			<input type="submit" value="Vaciar Cesta" name="vaciar" class="btn btn-warning disabled">
			<input type="submit" value="Volver" name="volver" class="btn btn-warning disabled">
			
		</div>	
				
	</form>
	<!-- FIN DEL FORMULARIO -->
	</div>	
  </div>

</body>
</html>

