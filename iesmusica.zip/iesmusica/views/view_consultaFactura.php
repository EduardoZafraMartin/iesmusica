<?php
    if(!isset ($_SESSION)){
        session_start();
    }

    if(!isset ($_SESSION ['logueado']) || ($_SESSION ['logueado'] ==false)){
        header("location: view_login.php");
    }
?>
<html>
   <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SPOTIFY - IES Leonardo Da Vinci - Alquiler Películas</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">

    <style>
            table, td, th {
            border: 1px solid black;
            background-color:aquamarine;
            text-align: center
            }
            table {
            border-collapse: collapse;  
            width: 50%;
            }
            

        </style>
    </head>
   

   
   <body>
   

     <div class="container ">
        <!--Aplicacion-->
		<div class="card border-success mb-3" style="max-width: 30rem;">
		<div class="card-header">Consultar Factura - SPOTIFY Leonardo Da Vinci</div>
		<div class="card-body">
    <B>Nombre Cliente:</B><?php echo $_SESSION['FirstName']; ?> <BR>
	<B>Id Cliente:</B><?php echo $_SESSION['CustomerId']; ?> <BR>
	<B>Compañia:</B> <?php echo $_SESSION['Company']; ?><BR><BR>

    <form method="POST" action="../controllers/controller_consultaFactura.php">
	
	<B>Número Factura: </B><select name="facturas" class="form-control" style="text-align:left;color: red;background: #f0f0f0;" required>
        <?php foreach ($facturas as $factura) : ?>
        <?php echo '<option value="' . $factura['InvoiceId']  . '"> Factura ' . $factura['InvoiceId'] . '</option>'; ?>
        <?php endforeach; ?>
				
	</select>
		
		<BR>
		<BR>		
		<div>
		    <input type="submit" value="Datos Factura" name="consultar" class="btn btn-warning disabled">
			<input type="submit" value="Volver" name="Volver" class="btn btn-warning disabled">
		</div>		
	</form>

    <?php 
        if (isset($_POST['consultar'])){
            ?>
            <table>
                <tr><td>Linea</td><td>Cancion</td><td>Compositor</td></tr>
                    <?php foreach ($informacionFactura as $factura) : ?>
                    <?php echo '<tr><td>' .  $factura['InvoiceLineId'] . '</td><td>' . $factura['Name'] . '</td><td>' . $factura['Composer'] . '</td></tr>'; ?>
                    <?php endforeach; ?>
            </table>
            <?php
        }
    ?>
	<!-- FIN DEL FORMULARIO -->
  </div>



</body>
</html>

