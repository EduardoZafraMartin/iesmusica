<?php


require_once("../db/db.php");

function facturas($CustomerId)  {
        $conexion=generarConexion();
            try {
    
                $sql=("SELECT InvoiceId, InvoiceDate,Total FROM invoice WHERE CustomerId='$CustomerId'");
                $statement = $conexion->prepare($sql);
                $statement->execute();
                $resultado=$statement->fetchAll(PDO::FETCH_ASSOC);
               
                return $resultado;
                
            }   catch (PDOException $ex) {
                echo "<strong>ERROR: </strong> ". $ex->getMessage();
            }
    
        }

        function informacionFactura($invoiceId)  {
            $conexion=generarConexion();
                try {
        
                    $sql=("SELECT invoiceline.InvoiceLineId, track.Name, track.Composer FROM invoiceline,
                     track WHERE invoiceline.TrackId = track.TrackId AND invoiceline.InvoiceId = '$invoiceId'");
                    $statement = $conexion->prepare($sql);
                    $statement->execute();
                    $resultado=$statement->fetchAll(PDO::FETCH_ASSOC);
                   
                    return $resultado;
                    
                }   catch (PDOException $ex) {
                    echo "<strong>ERROR: </strong> ". $ex->getMessage();
                }
        
            }
