<?php
    require_once("../db/db.php");


    function generarInvoice($conexion,$customerId,$precio) {

    $idMax=(sumarIdInvoice());
    $idInt=intval($idMax['max(InvoiceId)']);
    $invoiceId=($idInt + 1);
    
    
            $conexion -> query("INSERT into invoice
            (InvoiceId,CustomerId,InvoiceDate,Total) values ('$invoiceId','$customerId',CURRENT_TIMESTAMP(),'$precio')");
            
           
            
           /* $query2 = "SELECT MAX(InvoiceId) AS InvoiceId FROM invoice";
            $obtenerID = $conexion->prepare($query2);
            $obtenerID->execute();
            return $query2;*/
            

        
    }

    function generarInvoiceLine($conexion,$invoiceLineId,$invoiceId,$trackId,$precio) {
        
    $precioDecimal = floatval($precio);
    $invoiceIdInt = intval($invoiceId);
    $trackIdInt = intval($trackId);

        
            $conexion -> query("INSERT into invoiceline
            (InvoiceLineId,InvoiceId,TrackId,UnitPrice,Quantity) values ('$invoiceLineId','$invoiceIdInt','$trackIdInt','$precioDecimal',1)");
            
        
    }

    function dameUltimoId($conexion)  {
        
            try {
    
                $sql=("SELECT MAX(InvoiceId) AS InvoiceId FROM invoice");
                $statement = $conexion->prepare($sql);
                $statement->execute();
                $resultado=$statement->fetch(PDO::FETCH_ASSOC);
               
                return $resultado['InvoiceId'];
                
            }   catch (PDOException $ex) {
                echo "<strong>ERROR: </strong> ". $ex->getMessage();
                //$conexion->rollback();
            }
    
        }


    

    function dameCanciones()  {
        $conexion=generarConexion();
            try {
    
                $sql=("SELECT TrackId, Name, Composer, UnitPrice FROM track ");
                $statement = $conexion->prepare($sql);
                $statement->execute();
                $resultado=$statement->fetchAll(PDO::FETCH_ASSOC);
               
                return $resultado;
                
            }   catch (PDOException $ex) {
                echo "<strong>ERROR: </strong> ". $ex->getMessage();
            }
    
        }

        function sumarIdInvoice(){


            $conexion=generarConexion();
    
            try {
                $obtenerID = $conexion->prepare("SELECT max(InvoiceId) from Invoice");
                $obtenerID->execute();
               
                
                return $obtenerID->fetch(PDO::FETCH_ASSOC);
            }   catch (PDOException $ex) {
                echo $ex->getMessage();
            }
    
    
        }

        function dameUltimoInvoiceLineId(){


            $conexion=generarConexion();
    
            try {
                $obtenerID = $conexion->prepare("SELECT max(InvoiceLineId) as lastId from InvoiceLine");
                $obtenerID->execute();
            
                $id = $obtenerID->fetch(PDO::FETCH_ASSOC);
                return intval($id['lastId']);
            }   catch (PDOException $ex) {
                echo $ex->getMessage();
            }
    
    
        }
