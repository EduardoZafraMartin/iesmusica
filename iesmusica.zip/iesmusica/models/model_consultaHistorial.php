<?php


require_once("../db/db.php");

function facturas($CustomerId, $fechaInicio, $fechaFin)  {
        $conexion=generarConexion();
            try {
    
                $sql=("SELECT InvoiceId, InvoiceDate,Total FROM invoice WHERE CustomerId='$CustomerId' and InvoiceDate  BETWEEN '$fechaInicio' AND '$fechaFin'");
                $statement = $conexion->prepare($sql);
                $statement->execute();
                $resultado=$statement->fetchAll(PDO::FETCH_ASSOC);
               
                return $resultado;
                
            }   catch (PDOException $ex) {
                echo "<strong>ERROR: </strong> ". $ex->getMessage();
            }
    
        }
