<?php
require_once("../db/db.php");

function dameUsuario($email,$apellido)  {
    $conexion=generarConexion();
        try {

            $sql=("SELECT Email,CustomerId,FirstName,LastName,Company FROM customer WHERE Email='$email' AND LastName='$apellido'");
            $statement = $conexion->prepare($sql);
            $statement->bindParam(":Email", $email);
            $statement->bindParam(":LastName", $apellido);
            $statement->execute();
            $resultado=$statement->fetch(PDO::FETCH_ASSOC);
            return $resultado;
            
        }   catch (PDOException $ex) {
            echo "<strong>ERROR: </strong> ". $ex->getMessage();
        }

    }
        
?>