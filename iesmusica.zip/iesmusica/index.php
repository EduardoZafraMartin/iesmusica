<html>

<head>
    
</head>
<body>         
    <h1>Aplicacion Portal Musica</h1>    
          <a href="./views/view_login.php">Login</a>
</body>
</html>