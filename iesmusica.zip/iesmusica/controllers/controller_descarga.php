<?php


require ('../models/model_descarga.php');
include '../models/apiRedsys.php';

session_start();


if (!isset($_SESSION['DESCARGA_CANCIONES'])){
    $_SESSION['DESCARGA_CANCIONES'] = array();
}

    $canciones = dameCanciones();

    if(isset($_POST['agregar'])){
        
        $cancion = $_POST['cancion']; 
        array_push($_SESSION['DESCARGA_CANCIONES'],$cancion);

    }

    if(isset($_POST['descargar'])){

        if(empty($_SESSION['DESCARGA_CANCIONES'])){

            echo("El carrito esta vacio");
        }else{

            $cancionesDescargadas = $_SESSION['DESCARGA_CANCIONES'];
            $precioTotal = 0;
        

        for ($i=0; $i < count($cancionesDescargadas) ; $i++) { 

            $cancionDescargada = $cancionesDescargadas[$i];
            $cancion = explode("_and_",$cancionDescargada);
            $trackId= $cancion[0];   
            $precioCancion = $cancion[1]; 
            $precioTotal= $precioTotal + $precioCancion;

        }

        // ---------------------------------------------------------------------------------------------------------------




       //Pasarela de pago
       $titular=$_SESSION['FirstName'];//_POST
       $negocio="PortalMusica";
       $fuc="999008881";
       $terminal="001";
       $moneda="978";
       $trans="0";
       $url="";
       $urlOk="http://localhost/iesmusica/controllers/controller_pagoRealizado.php";
       $urlKo="http://localhost/iesmusica/controllers/controller_pagoNoRealizado.php";
       
       $id=strval(rand(1,999999999999));
       //Convertir 10.00 a 1000
       $precioTotal = $precioTotal * 100;

       $miObj = new RedsysAPI;
       /* Calcular el parámetro Ds_MerchantParameters. Para llevar a cabo el cálculo
       de este parámetro, inicialmente se deben añadir todos los parámetros de la
       petición de pago que se desea enviar, tal y como se muestra a continuación: */
       $miObj->setParameter("DS_MERCHANT_AMOUNT", $precioTotal);
       $miObj->setParameter("DS_MERCHANT_ORDER", $id);
       $miObj->setParameter("DS_MERCHANT_MERCHANTCODE", $fuc);
       $miObj->setParameter("DS_MERCHANT_CURRENCY", $moneda);
       $miObj->setParameter("DS_MERCHANT_TRANSACTIONTYPE", $trans);
       $miObj->setParameter("DS_MERCHANT_TERMINAL", $terminal);
       $miObj->setParameter("DS_MERCHANT_URLOK", $urlOk);
       $miObj->setParameter("DS_MERCHANT_URLKO", $urlKo);
       /*Por último, para calcular el parámetro Ds_MerchantParameters, se debe
       llamar a la función de la librería “createMerchantParameters()”, tal y como
       se muestra a continuación: */
       $params = $miObj->createMerchantParameters();
       /* Calcular el parámetro Ds_Signature. Para llevar a cabo el cálculo de
       este parámetro, se debe llamar a la función de la librería
       “createMerchantSignature()” con la clave SHA-256 del comercio (obteniendola
       en el panel del módulo de administración), tal y como se muestra a
       continuación: */
       $claveSHA256 = 'sq7HjrUOBfKmC576ILgskD5srU870gJ7';
       $firma = $miObj->createMerchantSignature($claveSHA256);
       $_SESSION['merchantParametersEncriptados']= $params;
       $_SESSION['claveComercio']= $firma;   
       
       header("location: ../views/view_confirmaSaldo.php");
    }


    }

    if (isset($_POST['volver'])) {

        header("location: ../views/view_welcome.php");
         
    }
 
    if(isset($_POST['vaciar'])){

        $_SESSION['DESCARGA_CANCIONES'] = array();
        
    }

require_once("../views/view_descarga.php");
