<?php

require('../models/model_consultaHistorial.php');

session_start();

if (isset($_POST['consultar'])) {

    $customerId = $_SESSION['CustomerId'];
    $fechaInicio = $_POST['fechadesde'];
    $fechaFin = $_POST['fechahasta'];
    $facturas = facturas($customerId, $fechaInicio, $fechaFin);
}

if (isset($_POST['Volver'])) {

    header("location: ../views/view_welcome.php");
}

require_once('../views/view_consultaHistorial.php');
