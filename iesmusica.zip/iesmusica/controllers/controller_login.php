<?php

//include_once '../db/db.php';
include_once '../models/model_login.php';
include_once '../views/view_login.php';


$email=$_POST['usuario'];
$apellido=$_POST['clave'];
$apellidoAlReves = strrev($apellido) ;
var_dump($apellidoAlReves);


	if(isset($_POST['submit'])){//Si no se ha pulsado el boton de login cierra sesión
            if(isset($email) && isset($apellidoAlReves))
			{//Si se han rellenado los campos del login
                $resultado = dameUsuario($email,$apellidoAlReves);
                if($resultado['Email'] ==$email && $resultado['LastName'] ==$apellidoAlReves){
                    session_start();
                    $_SESSION['Email']=$resultado['Email'];
                    $_SESSION['LastName']=$resultado['LastName'];
                    $_SESSION['CustomerId']=$resultado['CustomerId'];
                    $_SESSION['FirstName']=$resultado['FirstName'];
                    $_SESSION['Company']=$resultado['Company'];
                    $_SESSION['logueado']=true;
                    header("location: ../views/view_welcome.php");
                }
				else{
                    echo "No existe ningun email con esa contrase&ntilde;a.";
					}
            }
			else
			{
                if(!isset($_POST['usuario']))
				{
                    echo "No se ha proporcionado un usuario!";
                }
                if(!isset($_POST['clave']))
				{
                    echo "No se ha proporcionado una contrase&ntilde;a!";
                }
			}
          }



$resultado = dameUsuario($email,$apellidoAlReves);
    if ($resultado['Email'] == $email && $resultado['LastName'] == $apellidoAlReves){
        session_start();
        $_SESSION['Email']=$resultado['Email'];
        $_SESSION['LastName']=$resultado['LastName'];
        $_SESSION['CustomerId']=$resultado['CustomerId'];
        $_SESSION['FirstName']=$resultado['FirstName'];
        $_SESSION['Company']=$resultado['Company'];
        $_SESSION['logueado']=true;

        header("location: ../views/view_welcome.php");

    }else{
        echo ("Usuario o contraseña incorrecto");
        
}
