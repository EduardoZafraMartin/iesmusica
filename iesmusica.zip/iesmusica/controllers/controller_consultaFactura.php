<?php

require('../models/model_consultaFactura.php');

session_start();

$customerId = $_SESSION['CustomerId'];
$facturas = facturas($customerId);




if (isset($_POST['consultar'])) {

    $invoiceId = $_POST['facturas'];
    $informacionFactura = informacionFactura($invoiceId);
}

if (isset($_POST['Volver'])) {

    header("location: ../views/view_welcome.php");
}



require_once('../views/view_consultaFactura.php');
