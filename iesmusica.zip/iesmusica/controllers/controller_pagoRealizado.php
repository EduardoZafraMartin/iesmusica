<?php
  
    session_start();

    require_once("../db/db.php");
    include '../models/apiRedsys.php';
    require ('../models/model_descarga.php');

    $cancionesDescargadas = $_SESSION['DESCARGA_CANCIONES'];
    $precioTotal = 0;
    

    for ($i=0; $i < count($cancionesDescargadas) ; $i++) { 

        $cancionDescargada = $cancionesDescargadas[$i];
        $cancion = explode("_and_",$cancionDescargada);
        $trackId= $cancion[0];   
        $precioCancion = $cancion[1]; 
        //Metodo que devuelve el precio total
        $precioTotal= $precioTotal + $precioCancion;

    }

    //Una vez generado el invoice, guardar el id para poder pasarselo al invoiceLine.

    $customerId=$_SESSION['CustomerId'];

    try{

        $conexion = generarConexion();
        $conexion->beginTransaction();

        generarInvoice($conexion,$customerId,$precioTotal);

        $invoiceId = dameUltimoId($conexion);
        $ultimoInvoiceLineId = dameUltimoInvoiceLineId();
    
        for ($i=0; $i < count($cancionesDescargadas); $i++) { 
            $cancionDescargada = $cancionesDescargadas[$i];
            $cancion = explode("_and_",$cancionDescargada);
            $trackId= $cancion[0];  
            $precioCancion = $cancion[1];  
            $invoiceLineId = $ultimoInvoiceLineId + $i+1;
            $invoiceLine=generarInvoiceLine($conexion,$invoiceLineId,$invoiceId,$trackId,$precioCancion);  
        }

        //Prueba de que funciona rollback

        //$conexion -> query("INSERT into invoiceline
        //(InvoiceLineId,InvoiceId,TrackId,UnitPrice) values (54,100,3,0.98)");
    
        $conexion -> commit();
        

    } catch (PDOException $ex) {
            echo $ex->getMessage();
            $conexion->rollback();
        }
   
   if (isset($_SESSION['DESCARGA_CANCIONES'])) {
      
       $_SESSION['DESCARGA_CANCIONES'] = array();
      
        header("location: ../views/view_welcome.php");
    }
